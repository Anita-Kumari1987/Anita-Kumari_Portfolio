import Testimonials from "@/components/Testimonials";

export default function Page() {
  return (
    <>
      <Testimonials />
    </>
  );
}
