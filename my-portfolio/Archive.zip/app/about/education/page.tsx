import EducationTimeline from "@/components/EducationTimeline";

export const metadata = { title: "Education" };

export default function Page() {
  return <EducationTimeline />;
}
