// app/about/experience/page.tsx
import ExperienceGrid from "../../../components/ExperienceGrid";

export const metadata = { title: "Experience" };

export default function ExperiencePage() {
  return <ExperienceGrid />;
}
