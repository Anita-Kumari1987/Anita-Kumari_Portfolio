import MarqueeDemo from "@/components/marquee-demo";
import OrbitingCirclesDemo from "@/components/TechStackCard"

export const metadata = { title: "My Tech Stack" };

export default function Page() {
  return (
  <OrbitingCirclesDemo />
  )
}
