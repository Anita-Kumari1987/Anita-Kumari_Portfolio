import FAQContent from "@/components/Faq-Page";

export default function Page() {
  return (
    
    <FAQContent /> 
  );
}

