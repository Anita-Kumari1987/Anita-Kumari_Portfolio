import HeaderText from "@/components/HeaderText";
import HeroHeadline from "@/components/HeroHeadline";

export default function Page() {
return (
  <>
  <HeroHeadline/>
</>
);
}