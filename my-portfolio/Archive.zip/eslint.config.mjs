// eslint.config.mjs
import next from "eslint-config-next";
export default [...next(["core-web-vitals", "typescript"])];
